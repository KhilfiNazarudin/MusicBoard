package pkg;

import ryanguru.ColorDisplay;

public class YourCode
{
	public static void Blink()
	{
		ColorDisplay.setPixelColor(5, 10, "RED");
		ColorDisplay.pause(30);
		ColorDisplay.setPixelOFF(5, 10);
	}

	public static void onBeat(int c)
	{
		System.out.println("At beat : " + c);

		// Replace the below with your own code to dance

		Blink(); // This is just for testing your mp3 that it responds to the beats.

	}

}